<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/assets/statics/base/css/metinfo.css" />
<link rel="stylesheet" type="text/css" href="/assets/statics/base/css/newstyle.css" />
<script type="text/javascript">var basepath='/assets/statics/base/images';</script>
<script type="text/javascript" src="/assets/statics/base/js/metvar.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/jQuery1.7.2.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/iframes.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/cookie.js"></script>
<script src="/assets/statics/lib/ufinder/lib/jquery-1.11.0.min.js"></script>
<link rel="stylesheet" href="/assets/statics/lib/ufinder/themes/css/ufinder.css?s"/>
<script type="text/javascript">
/*ajax执行*/
var realUrl = '/data/upfile';
var lang = 'cn';
var metimgurl='/assets/statics/base/images/';
var depth='../';
$(document).ready(function(){
	ifreme_methei();
});
</script>
<!--[if lte IE 9]>
<SCRIPT language=JavaScript>  
function killErrors() {  
return true;  
}  
window.onerror = killErrors;  
</SCRIPT> 
<![endif]-->

</head>
<body>

<script type="text/javascript">
function metreturn(url){
	if(url){
		location.href=url;
	}else if($.browser.msie){
		history.go(-1);
	}else{
		history.go(-1);
	}
}
</script>
	<div class="metinfotop">
	<div class="position">简体中文 > 企业应用 > <a href="index.php/admin/app">我的应用</a></div>
	</div>
	<div class="clear"></div>

<script type="text/javascript">
$("html",parent.document).find('.returnover').remove();
</script>


</div>

<div class="stat_list">
	<ul>
		<li class="now"><a href="#" title="文件管理器">文件管理器</a></li>
		 
	</ul>
</div>
<div class='clear'></div>

<!--<script type="text/javascript" src="/assets/statics/lib/ckfinder/ckfinder.js?1426038859"></script>-->
<div class="v52fmbx_tbmax">
<div class="v52fmbx_tbbox">
<div class="v52fmbx">	

<div id="container"></div>
<script src="/assets/statics/lib/ufinder/ufinder.config.js?2"></script>
<script src="/assets/statics/lib/ufinder/ufinder.js"></script>
<script src="/assets/statics/lib/ufinder/lang/zh-cn/zh-cn.js"></script>
<script>
    $(function () {
        window.uf = UF.getUFinder('container');
    });
</script>

<!--<div id="ckfinder"></div>-->
</div>
</div>
</div>

	<div class="footer">Powered by <b><a href="http://www.phpci.com" target="_blank">phpci 6.0.0 </a></b> &copy;2008-2015 &nbsp;<a href="http://www.phpci.com" target="_blank">phpci Inc.</a> in 0.1438 seconds </div>

</body>
</html>
