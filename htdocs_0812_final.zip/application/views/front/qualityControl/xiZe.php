<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>认证机构介绍</title>

<style >
  
  #details ol{line-height:30px;}
  p{text-align: center;background:#999998}
</style>
</head>

<body>
<div id="details">
<p>中国胸痛中心自主认证</p>
   <ol>
     <li><a href="#">中国胸痛中心认证标准(第五版)下载</a></li>
    <li><a href="#">中国胸痛中心认证评分细则(第五版)下载</a></li>
      <li><a href="#">中国基层胸痛中心认证标准(第一版)下载</a></li>
        <li><a href="#">中国基层胸痛中心认证评分细则(第一版)下载</a></li>
</ol>
</div>
</body>
</html>
