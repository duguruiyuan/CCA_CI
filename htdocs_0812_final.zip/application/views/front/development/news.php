
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="" />
<meta name="keywords" content="" />
<title>中国急性心肌梗死救治项目</title>


<link href="/assets/css/base.css" rel="stylesheet" type="text/css">
<link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link  href="/assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/assets/css/base.css" rel="stylesheet" type="text/css">
<link href="/assets/css/style.css" rel="stylesheet" type="text/css" media="all">
<link href="/assets/css/shouye.css" rel="stylesheet" type="text/css">

<!-- <script src="/js/jquery.min.js"></script> -->
<script src="/assets/js/jquery-1.11.3.min.js"></script>
<script src="/assets/js/bootstrap.min.js"></script>
<script src="/assets/js/md5.min.js"></script>
<script type="text/javascript" language="javascript" src="/assets/js/jquery.dropdownPlain.js"></script>
	
  <style>
tr{ height:30px;}
.news_1{ margin:0 auto; margin-top:50px;}
  </style>

</head>

<body>
  <!--header start-->

 <?php  include 'common/_header.php'  ?>
  <!--header end-->
<div id="wrapper" class="homebg">
<!--header start-->

<!--header end-->

<!--content start-->
<center>
<form class="news_1">
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="280" valign="top"><table width="260" border="0" align="left" cellpadding="0" cellspacing="0">
      <tr>
        <td width="260" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="26%" height="30" align="left" class="font_14"><strong>产品中心</strong></td>
            <td width="47%" align="left" class="font_999">Product</td>
            <td width="27%" align="right"><img src="/assets/img/w.png" width="37" height="11" /></td>
          </tr>
        </table>
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="103" align="left"><img src="/assets/img/q.png" width="76" height="76" /></td>
                  <td align="center"><img src="/assets/img/q.png" width="76" height="76" /></td>
                  <td align="right"><img src="/assets/img/q.png" width="76" height="76" /></td>
                </tr>
            </table></td>
      </tr>
      <tr>
        <td valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="26%" align="left" class="font_14"><strong>新闻中心</strong></td>
            <td width="47%" align="left" class="font_999">News</td>
            <td width="27%" align="right"><img src="/assets/img/q.png" width="37" height="11" /></td>
          </tr>
          <tr>
            <td height="110" colspan="3" align="left" ><table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
              <tr>
                <td width="71%" align="left" class="xuxian"><a href="../newsite.html" target="_blank">·中国胸痛中心产品</a></td>
              </tr>
              <tr>
                <td align="left" class="xuxian"><a href="../newsite.html" target="_blank">·中国胸痛中心产品？</a></td>
              </tr>
              <tr>
                <td align="left" class="xuxian"><a href="../newsite.html" target="_blank">·中国胸痛中心产品</a></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td valign="top"><img src="/assets/img/cp.jpg" width="257" height="122" /></td>
      </tr>
    </table></td>
    <td width="720" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td width="71%" align="left" class="font_14 xuxian"><strong><h3>新闻中心</h3></strong></td>
      </tr>
    </table>
       <table width="100%" border="0" cellpadding="0" cellspacing="20" class="hg_30">
          <tr valign="top">
            <td align="left"><table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
                <tr>
                  <td width="85%" align="left" class="xuxian"><a href="/home/notices1" target="_blank"> 滔滔洪水，难挡中国胸痛中心前行之路！</a></td>
                  <td width="15%" align="center" class="xuxian">2016-07-07</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices2" target="_blank">胸痛中心建设-天津模式 </a></td>
                  <td align="center" class="xuxian">2016-05-20</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices3" target="_blank"> 第七批中国胸痛中心核查现场报道</a></td>
                  <td align="center" class="xuxian">2016-05-06</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank">中国胸痛中心认证工作委员会第七次执委会会议报道 </a></td>
                  <td align="center" class="xuxian">2016-04-28</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices4" target="_blank">胸闷、胸痛，速打120 —泸州胸痛中心正在筹建中</a></td>
                  <td align="center" class="xuxian">2016-03-19</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank"> 中国胸痛中心认证工作委员会第四次全委会现场报道 </a></td>
                  <td align="center" class="xuxian">2016-03-02</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank"> 第六批通过中国胸痛中心认证单位授牌仪式现场报道 </a></td>
                  <td align="center" class="xuxian">2016-02-20</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank">第五届中国胸痛中心高峰论坛在广州隆重召开</a></td>
                  <td align="center" class="xuxian">2015-12-19</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank">广东省县级医院胸痛中心建设试点工程近日启动 </a></td>
                  <td align="center" class="xuxian">2015-12-18</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank">中国胸痛中心认证工作的监督机制</a></td>
                  <td align="center" class="xuxian">2015-12-01</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank">我对中国胸痛中心建设与发展的思考</a></td>
                  <td align="center" class="xuxian">2015-11-14 </td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank">非PCI医院开展胸痛中心建设的必要性 </a></td>
                  <td align="center" class="xuxian">2015-11-13</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank"> 区域协同救治体系的建立 ——中国胸痛中心认证标准制订的理论基础</a></td>
                  <td align="center" class="xuxian">2015-11-13</td>
                </tr>
                <tr>
                  <td align="left" class="xuxian"><a href="/home/notices5" target="_blank">第五批通过中国胸痛中心认证单位授牌仪式现场报道</a></td>
                  <td align="center" class="xuxian">2015-11-13</td>
                </tr>
            </table></td>
          </tr>
      </table></td>
  </tr>
</table>
</form>
</center>
<!--content end-->

<!--footer start-->

 <?php include 'common/_footer.php' ?>
 
<!--footer end-->
</div>
</body>
</html>
