<head>
	<link rel="stylesheet" type="text/css" href="/assets/css/a.css">
</head>


<body>
	<form action="/login/login_check" method="post">
		Username<input type="text" name="uname" /><br/>
		Password<input type="text" name="passwd" /><br/>
		<input type="submit" value="Submit">
	</form>
</body>