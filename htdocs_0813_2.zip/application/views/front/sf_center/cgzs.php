
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="" />
<meta name="keywords" content="" />
<title>中国急性心肌梗死救治项目</title>


<link href="/assets/css/base.css" rel="stylesheet" type="text/css">
<link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link  href="/assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/assets/css/base.css" rel="stylesheet" type="text/css">
<link href="/assets/css/style.css" rel="stylesheet" type="text/css" media="all">
<link href="/assets/css/shouye.css" rel="stylesheet" type="text/css">

<!-- <script src="/js/jquery.min.js"></script> -->
<script src="/assets/js/jquery-1.11.3.min.js"></script>
<script src="/assets/js/bootstrap.min.js"></script>
<script src="/assets/js/md5.min.js"></script>
<script type="text/javascript" language="javascript" src="/assets/js/jquery.dropdownPlain.js"></script>
	
  <style>
.cgzs{ width:1000px; height:1100px; margin:0 auto; margin-top:30px; margin-bottom:30px;}
.cgzs_left{ width:300px; height:600px; float:left; background-color:#ECDDDD}
.cgzs_right{ width:800px;  margin-left:30px;  text-align:center}
.cgzs_left img{ margin-left:30px}
.cgzs_left p{ margin-left:40px;}
  </style>

</head>

<body>
  <!--header start-->

 <?php  include 'common/_header.php'  ?>
  <!--header end-->
<div id="wrapper" class="homebg">


<!--content start-->
<div class="cgzs">
<div class="cgzs_left"><br>
<strong style="margin-left:50px; margin-bottom:50px;">新的胸痛中心成立</strong>
<img src="../../../../assets/img/ccpc.png"><p>天津市宝坻区人民医院</p><img src="../../../../assets/img/ccpc1.png"><P>中国人民解放军总医院</P></div>
<div class="cgzs_right"><P style=" color:red; text-align:center"><strong>目前已有84家医院认证</strong></P></div>
</div>
<!--content end-->

<!--footer start-->

 <?php include 'common/_footer.php' ?>
 
<!--footer end-->
</div>
</body>
</html>
