<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>添加广告</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/assets/statics/base/css/metinfo.css" />
<link rel="stylesheet" type="text/css" href="/assets/statics/base/css/newstyle.css" />
<script type="text/javascript">var basepath='/assets/statics/base/images';</script>
<script type="text/javascript" src="/assets/statics/base/js/metvar.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/jQuery1.7.2.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/iframes.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/cookie.js"></script>
<script charset="utf-8" src="/assets/statics/lib/kind/kindeditor-min.js"></script>
<script charset="utf-8" src="/assets/statics/lib/kind/lang/zh_CN.js"></script>
<script type="text/javascript">
var gettagspath="";
var upload_json="/assets/statics/lib/kind/php/upload_json.php";
var file_manager_json="/assets/statics/lib/kind/php/file_manager_json.php";
KindEditor.ready(function(K) {
    var editor = K.create('textarea[name="info"]', {
		urlType : 'domain',
		allowFileManager : true
	});
	K('#image').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
				imageUrl : K('#pic').val(),
					clickFn : function(url, title, width, height, border, align) {
						K('#pic').val(url);
						$("#img").attr("src",url);
						editor.hideDialog();
					}
			});
		});
	});
});
</script>
<script type="text/javascript">
$(document).ready(function(){
	ifreme_methei();
});
</script>
</head>
<body>
	<div class="metinfotop">
	<div class="position">简体中文：网站设置 > <a href="/admin/home/expand_ad">站内广告</a> > 添加广告</div>
	<div class="return"><a href="javascript:;" onClick="location.href='javascript:history.go(-1)'">&lt;&lt;返回</a></div>
	</div>
	<div class="clear"></div>
	<div class="stat_list">
		<ul>
			<li class="now"><a href="/admin/home/expand_ad" title="站内广告">站内广告</a></li>
			<li ><a href="/admin/home/expand_adcat" title="广告类别">广告类别</a></li>
		</ul>
	</div>
<div style="clear:both;"></div>
<form  method="post" name="myform" action="index.php/admin/expand_ad/add">
<div class="v52fmbx_tbmax">
<div class="v52fmbx_tbbox">
<div class="v52fmbx">
		<div class="v52fmbx_dlbox">
		<dl>
			<dt>广告类别：</dt>
			<dd>
			<select name="cid">
				<option value="">广告类别</option>
								<option value="18">合作客户</option>
								<option value="17">左边广告</option>
								<option value="16">首页幻灯片</option>
							</select>
			</dd>
		</dl>
		</div>
		
		<div class="v52fmbx_dlbox">
		<dl>
			<dt>广告名称：</dt>
			<dd>
				<input name="title" type="text" class="text nonull" value="">
			</dd>
		</dl>
		</div>
		
		
		<div class="v52fmbx_dlbox">
		<dl>
			<dt>链接网址：</dt>
			<dd>
				<input name="url" type="text" class="text" value="http://">
			</dd>
		</dl>
		</div>
		
		<!--<div class="v52fmbx_dlbox">
		<dl>
			<dt>图片预览：</dt>
			<dd>
				</assets/img id="img" width="80" height="50" src="statics/base/images/nopic.gif">
			</dd>
		</dl>
		</div>-->
		
		<div class="v52fmbx_dlbox">
		<dl>
			<dt>广告文件：</dt>
			<dd>
				<input name="pic" type="text" id="pic" class="text" value="">
				<input type="button" id="image" class="bnt_public" value="图片上传"/>
				</assets/img id="img" width="80" height="50" src="statics/base/images/nopic.gif">
			</dd>
		</dl>
		</div>
		

		
		<div class="v52fmbx_dlbox">
		<dl>
			<dt>图片宽高：</dt>
			<dd>
				<input name="ad_w" type="text" class="text mid" value="100">宽  <input name="ad_h" type="text" class="text mid" value="100">高
			</dd>
		</dl>
		</div>
		
		<div class="v52fmbx_dlbox">
		<dl>
			<dt>排序：</dt>
			<dd>
				<input name="ordnum" type="text" class="text mid" value="0">
			</dd>
		</dl>
		</div>
		
		<div class="v52fmbx_dlbox">
		<dl>
			<dt>可选属性：</dt>
			<dd>
				<input name="status" type="checkbox" class="checkbox" value="1" checked>&nbsp;审核通过
			</dd>
		</dl>
		</div>
		
		<div class="v52fmbx_dlbox">
		<dl>
			<dt>广告内容：</dt>
			<dd>
				<textarea class="ckeditor" name="info" style="width:98%;"></textarea>
			</dd>
		</dl>
		</div>
		
		<div class="v52fmbx_dlbox v52fmbx_mo">
			<dl>
				<dt></dt>
				<dd>
					<input type="submit"  value="保存" class="submit" onclick="return Smit($(this),'myform')" />
				</dd>
			</dl>
		</div>
	</div>
	<div class="v52fmbx_submit v52fmbx_mo" style="height:150px">
			<br>
			<br>
			<br>
	</div>
	
</div>
</div>
</div>      
</form>
<div class="footer">Powered by <b><a href="http://www.phpci.com" target="_blank">phpci 6.0.0 </a></b> &copy;2008-2015 &nbsp;<a href="http://www.phpci.com" target="_blank">phpci Inc.</a> in 0.1502 seconds </div>
</body>
</html>