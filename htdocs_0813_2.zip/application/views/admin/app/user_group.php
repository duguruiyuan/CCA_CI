<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/assets/statics/base/css/metinfo.css" />
<link rel="stylesheet" type="text/css" href="/assets/statics/base/css/newstyle.css" />
<script type="text/javascript">var basepath='/assets/statics/base/images';</script>
<script type="text/javascript" src="/assets/statics/base/js/metvar.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/jQuery1.7.2.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/iframes.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/cookie.js"></script>
<script type="text/javascript">
/*ajax执行*/
var lang = 'cn';
var metimgurl='/assets/statics/base/images/';
var depth='../';
$(document).ready(function(){
	ifreme_methei();
});
</script>
<!--[if lte IE 9]>
<SCRIPT language=JavaScript>  
function killErrors() {  
return true;  
}  
window.onerror = killErrors;  
</SCRIPT> 
<![endif]-->

<title></title>
</head>
<body>

<script type="text/javascript">
function metreturn(url){
	if(url){
		location.href=url;
	}else if($.browser.msie){
		history.go(-1);
	}else{
		history.go(-1);
	}
}
</script>
	<div class="metinfotop">

	<div class="position">简体中文 > 企业应用 > <a href="/admin/home/user_group">会员组设置</a></div>


	</div>
	<div class="clear"></div>

	</div>

<div class="stat_list">
	<ul>
		<li ><a href="/admin/home/user" title="会员管理">会员管理</a></li>
		<li class="now"><a href="/admin/home/user_group" title="会员组设置">会员组设置</a></li>
		<li ><a href="/admin/home/user_config" title="会员功能设置">会员功能设置</a></li>
	</ul>
</div>
<div style="clear:both;"></div>

<div class="v52fmbx_tbmax">
<div class="v52fmbx_tbbox">
<table cellpadding="2" cellspacing="1" class="table">
          <tr>
            <td class="centle" colspan="8" style=" height:20px; line-height:30px; font-weight:normal; padding-left:10px;">
				<div style="float:left;">
				<a href="user_group_add.html">+新增</a>
				</div>
				<div class="formright">	
				<a href="index.php/admin/user_group">显示所有</a>
				<form method="post" name="myform" action="index.php/admin/user_group/index">
				分组名&nbsp;<input name="keyword" type="text" class="text100" />
				<input type="submit" name="Submit2" value="搜索" class="bnt_pinyin">&nbsp;
				</form>
				</div>
			</td>
          </tr>
              <tr>
			    <td width="40" class="list" style="padding:0px; text-align:center;">选择</td>
                <td class="list">名称</td>
                <td width="100" class="list" style="padding:0px; text-align:center;">优惠率</td>
                <td width="90" class="list" style="padding:0px; text-align:center;">所需积分</td>
                <td width="100" class="list" style="padding:0px; text-align:center;">允许登录</td>
                <td width="90" class="list" style="padding:0px; text-align:center;">允许投稿</td>
				<td width="100" class="list" style="padding:0px; text-align:center;">允许升级</td>
				<td width="80" class="list" style="padding:0px; text-align:center;">操作</td>
              </tr>
			  
			<form name="myform" method="post" id="myform" action="index.php/admin/user_group/delsome?&page=1">
                          <tr class="mouse click">
                <td class="list-text"><input name="id[]" type="checkbox" id="id" value="1" /></td>
                <td class="list-text alignleft">&nbsp;&nbsp;<a href="index.php/admin/user_group/edit?id=1" title="查看详细">新手上路</a></td>
                <td class="list-text color999">10</td>
                <td class="list-text color999">1001</td>
                <td class="list-text color999"><span>否</span></td>
                <td class="list-text color999">(<span>10</span>)</td>
				<td class="list-text color999">是</td>
				<td class="list-text">
				<a href="user_group_edit.html">编辑</a>
				<a href="javascript:;" onclick="{if(confirm('确定删除吗?')){window.location='index.php/admin/user_group/del?id=1&&page=1';return true;}return false;}">删除</a>
				</td>
              </tr>
			  
   	   <tr> 
            <td width="40" class="all"><input name="chkAll" type="checkbox" id="chkAll" onclick=CheckAll(this.form) value="checkbox"> </td>
			  <td class="all-submit" colspan="8" style="padding:5px 10px;">
			  <input type='submit' value='删除' class="submit li-submit" onclick="{if(confirm('确定删除吗?')){document.myform.action='index.php/admin/user_group/delsome?&page=1';return true;}return false;}"/>
			  
              </td>
          </tr>
         </form>
		 <tr>
		  <td class="page_list" colspan="9"> 
		  <form method='POST' name='page1'  action='index.php/admin/user_group/index?&page=1' target='_self'><style>.digg4 a{ border:1px solid #ccdbe4; padding:2px 8px 2px 8px; background:#fff; background-position:50%; margin:2px; color:#666; text-decoration:none;}
.digg4 a:hover { border:1px solid #999; color:#fff; background-color:#999;}
.digg4 a:active {border:1px solid #000099; color:#000000;}
.digg4 span.current { padding:2px 8px 2px 8px; margin:2px; text-decoration:none;}
.digg4 span.disabled { border:1px solid #ccc; background:#fff; padding:1px 8px 1px 8px; margin:2px; color:#999;}
 </style>
 <div class='digg4'>
 <span class="disabled" style="font-family: Tahoma, Verdana;"><b>«</b></span><span class="disabled" style="font-family: Tahoma, Verdana;">‹</span><span class="current">1</span><span class="disabled" style="font-family: Tahoma, Verdana;">›</span><span class="disabled" style="font-family: Tahoma, Verdana;"><b>»</b></span>  共1条  转到<input name='page_input' class='page_input' />页  <input type='submit' name='Submit3' value=' go ' class='submit' /></form></div></td>
	  </tr>
	  
	  <tr>
		  <td class="footer" colspan="7">Powered by <b><a href="http://www.phpci.com" target="_blank">phpci 6.0.0 </a></b> &copy;2008-2015 &nbsp;<a href="http://www.phpci.com" target="_blank">phpci Inc.</a> in 0.1151 seconds </td>
	  </tr>
</table>
</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
	seachinput($('#searchtext'),'会员组名');
});
</script>
</body>
</html>

