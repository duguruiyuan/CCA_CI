<?php
	class Article_model extends MY_Model
	{
	    protected $TBL_NAME = 'article';
	}
?>