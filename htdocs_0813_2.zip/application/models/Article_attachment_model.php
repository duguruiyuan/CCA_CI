<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Article model
 *
 * @copyright       
 * @author          
 */
class Article_attachment_model extends MY_Model
{
	protected $TBL_NAME = 'article_attachment';
}