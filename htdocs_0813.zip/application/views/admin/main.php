<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>phpci企业网站管理系统</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/assets/statics/base/css/metinfo.css" />
<link rel="stylesheet" type="text/css" href="/assets/statics/base/css/newstyle.css" />
<script type="text/javascript">var basepath='/assets/statics/base/images';</script>
<script type="text/javascript" src="/assets/statics/base/js/metvar.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/jQuery1.7.2.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/iframes.js"></script>
<script type="text/javascript" src="/assets/statics/base/js/cookie.js"></script>
<script type="text/javascript">
/*ajax执行*/
var lang = 'cn';
var metimgurl='/assets/statics/base/images/';
var depth='';
$(document).ready(function(){
	ifreme_methei();
});
</script>
<!--[if lte IE 9]>
<SCRIPT language=JavaScript>  
function killErrors() {  
return true;  
}  
window.onerror = killErrors;  
</SCRIPT> 
<![endif]-->

</head>
<body>

<script type="text/javascript">
function metreturn(url){
	if(url){
		location.href=url;
	}else if($.browser.msie){
		history.go(-1);
	}else{
		history.go(-1);
	}
}
</script>
	<div class="metinfotop">

	<div class="position">简体中文 > 快捷导航 > <a href="/admin/home/main">系统信息</a></div>


	</div>
	<div class="clear"></div>

<script type="text/javascript">
$("html",parent.document).find('.returnover').remove();
</script>


</div>
<div class="sysadmin">
	<div class="sysadmin_box_1">
		<div class="sysadmin_box_cont">	
			<h3>访问概况</h3>
			<div class="boxcont" style="padding:0px;">
<table cellpadding="0" cellspacing="1" class="stat_table">
	<tr>
		<td class="t" width="30">日期</td>
		<td class="t" width="30">PV</td>
		<td class="t" width="30">访客</td>
		<td class="t" width="30">IP</td>
		<td class="t" width="30">次数</td>
	</tr>
	<tr class="mouse">
		<td class="t">今日</td>
		<td>1</td>
		<td>1</td>
		<td>1</td>
		<td>1</td>
	</tr>
	<tr class="mouse">
		<td class="t">昨日</td>
		<td>0</td>
		<td>0</td>
		<td>0</td>
		<td>0</td>
	</tr>
	<tr class="mouse">
		<td class="t">前日</td>
		<td>0</td>
		<td>0</td>
		<td>0</td>
		<td>0</td>
	</tr>
</table>
			</div>
		</div>
	</div>
	
	
	<div class="sysadmin_box_2">
		<div class="sysadmin_box_cont">
			<h3>内容信息</h3>
			<table cellpadding="0" cellspacing="1" class="stat_table">
				<tr class="mouse">
					<td class="t" width="60">文章数量</td>
					<td><a href="index.php/admin/news">1</a></td>
				</tr>
				<tr class="mouse">
					<td class="t">在线留言</td>
					<td><a href="index.php/admin/expand_book">4</a></td>
				</tr>
				<tr class="mouse">
					<td class="t">友情链接</td>
					<td><a href="index.php/admin/expand_link">4</a></td>
				</tr>
				<tr class="mouse">
					<td class="t">会员注册</td>
					<td><a href="index.php/admin/user">1</a></td>
				</tr>
			</table>
		</div>
	</div>
	
	
	
	<div class="sysadmin_box_3 none">
		<div class="sysadmin_box_cont">
			<h3>用户信息</h3>
			<ul class="user">
				<li><span>用户名：</span><div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

<h4>A PHP Error was encountered</h4>

<p>Severity: Notice</p>
<p>Message:  Undefined variable: adminuser</p>
<p>Filename: views/main.php</p>
<p>Line Number: 130</p>

</div></li>
				<li><span>登录次数：</span><div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

<h4>A PHP Error was encountered</h4>

<p>Severity: Notice</p>
<p>Message:  Undefined variable: loginhits</p>
<p>Filename: views/main.php</p>
<p>Line Number: 131</p>

</div></li>
				<li><span>IP：</span><div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

<h4>A PHP Error was encountered</h4>

<p>Severity: Notice</p>
<p>Message:  Undefined variable: loginip</p>
<p>Filename: views/main.php</p>
<p>Line Number: 132</p>

</div></li>
				<li><span>登录时间：</span><div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

<h4>A PHP Error was encountered</h4>

<p>Severity: Notice</p>
<p>Message:  Undefined variable: logintime</p>
<p>Filename: views/main.php</p>
<p>Line Number: 133</p>

</div></li>
			</ul>
		</div>
	</div>
	<div class="sysadmin_box_3">
		<div class="sysadmin_box_cont">
			<h3>Phpci新闻</h3>
			<div class="text" id="newslist"></div>
		</div>
	</div>
	<div class="clear"></div>
	<div class="sysadmin_box_6">
		<div class="sysadmin_box_cont">
			<h3>商业授权</h3>


		<div class="boxcont ">
		<form method="POST" name="myform"  action="index.php/admin/home" target="_self">
		    <input name="id" type="hidden" value="1">
			<div class="authdivinput">
				<input name="authpass" class="text nonull" placeholder="密钥" per="1" value="" />
			</div>
			<div class="authdivinput">
				<textarea name="authcode" rows="5" class="textarea nonull" placeholder="授权码" per="1"></textarea>
			</div>
			<div class="authsubmit">
				<input type="submit" name="Submit" value="录入" class="submit" onclick="return Smit($(this),'myform')" />
				<a href="http://www.phpci.com" target="_blank" title="了解商业授权" style="color:#f00; position:relative; left:4px;">了解商业授权</a>
			</div>
        </form>
			</div>
		</div>
	</div>
	<div class="sysadmin_box_8">
		<div class="sysadmin_box_cont">
		<h3>服务器信息</h3>
			<table cellpadding="0" cellspacing="1" class="stat_table">
				<tr class="mouse">
					<td class="t">程序名称</td>
					<td colspan='2'>phpci</td>
				</tr>
				<tr class="mouse">
					<td class="t">系统版本</td>
					<td colspan='2'>phpci 6.0.0 <font style="color:#390; padding-left:15px;">已是最新版本</font></td>
				</tr>
				<tr class="mouse">
					<td class="t">操作系统</td>
					<td colspan='2'>Windows XP (SP2)</td>
				</tr>
				<tr class="mouse">
					<td class="t">PHP | Mysql</td>
					<td>Apache/2.2.17 (Win32) PHP/5.3.3</td>
					<td>5.5.8-log</td>
				</tr>
				<tr class="mouse">
					<td class="t">版权所有</td>
					<td colspan='2'>小阳 QQ:357058607 <a href="http://wpa.qq.com/msgrd?v=3&uin=357058607&site=qq&menu=yes" target="_blank">
<img border="0" title="点击这里给我发消息" alt="点击这里给我发消息" src="http://wpa.qq.com/pa?p=2:357058607:47"></a></td>
				</tr>
				<tr class="mouse">
					<td class="t">在线升级</td>
					<td colspan='2'>
					<span id="oltest_cms" style="padding:0px; font-size:100%; color:#390;"><a id="updatenow" >检测更新</a></span>

					</td>
				</tr>
			</table>
		</div>
	</div>
	<div class="clear"></div>

	<div class="clear"></div>
	<div class="sysadmin_box_7">
		<div class="sysadmin_box_cont">
			<h3>服务与支持</h3>
			<div class="bangzhu">
				<ul>
				<li class="d"><a href="http://www.phpci.com" target="_blank">使用手册</a></li>
				<li class="to"><a href="http://www.phpci.com" target="_blank">商业授权</a></li>
				<li class="d"><a href="http://www.phpci.com" target="_blank">交流论坛</a></li>
				<li class="to"><a href="http://www.phpci.com" target="_blank">收费模板</a></li>
				<li class="d"><a href="http://www.phpci.com" target="_blank">官方网站</a></li>
				<li class="to"><a href="http://www.phpci.com" target="_blank">专用主机</a></li>
				<li class="d"><a href="mailto:357058607@qq.com">357058607@qq.com</a></li>
				<li class="to"><a href="http://www.phpci.com" target="_blank">定制开发</a></li>
				
				</ul>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<div class="clear"></div>
</div>
<div class="footer">Powered by <b><a href="http://www.phpci.com" target="_blank">phpci 6.0.0 </a></b> &copy;2008-2015 &nbsp;<a href="http://www.phpci.com" target="_blank">phpci Inc.</a> in 0.1469 seconds </div>
<script type="text/javascript">
//metgetdata('#newslist','http://www.metinfo.cn/metv5news.php?fromurl=&action=json');
function metHeight(group){
	tallest=0;
	group.each(function(){
		thisHeight=jQuery(this).height();
		if(thisHeight>tallest){
			tallest=thisHeight;
		}
	});
	group.height(tallest);
}

$(document).ready(function(){
	var autbox = $(".sysadmin_box_6 .boxcont");
	var fubox = $(".sysadmin_box_8 .stat_table");
	if(autbox.size()>0){
		var nhh = autbox.height()+12;
		if(fubox.height()<nhh){
			fubox.height(nhh);
		}else{
			autbox.height(fubox.height()-12);
		}
	}
	var group1 = $(".sysadmin_box_1 .stat_table,.sysadmin_box_2 .stat_table");
	metHeight(group1);
	ifreme_methei();
});
</script>

</body>
</html>