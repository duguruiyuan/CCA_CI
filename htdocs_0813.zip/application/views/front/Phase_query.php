 
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="" />
<meta name="keywords" content="" />
<title>中国胸痛中心总部</title>


<link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link  href="/assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/assets/css/base.css" rel="stylesheet" type="text/css">
<link href="/assets/css/query.css" rel="stylesheet" type="text/css">
<link href="/assets/css/style.css" rel="stylesheet" type="text/css">




<!-- <script src="/js/jquery.min.js"></script> -->
<script src="/assets/js/jquery-1.11.3.min.js"></script>
<script src="/assets/js/bootstrap.min.js"></script>
<script src="/assets/js/md5.min.js"></script>	
<script src="/assets/js/index.js"></script>

<script type="text/javascript" language="javascript" src="/assets/js/jquery.dropdownPlain.js"></script>


<style>

.load{
background-image:url(loader.gif);
background-position:right;
background-repeat:no-repeat;
}
    table{
        border:1px solid;
        width:800px;
        height:200px;
        float:middle;
        margin-top:50px; 
        margin-bottom: 100px;
}
   .table-b td,th {
    border:1px solid ;
	text-align:center;
   }
.skins{ text-align:left;
margin-left:300px; }


</style>

</head>

<body>

<div id="wrapper" class="homebg">
<!--header start-->
   <?php  include 'common/_header.php'  ?> 
<!--header end-->
  
<!--content start-->

<div>
<center>
<form>
  <table class="table-b">
    <tr>
    <th>编码</th>
    <th>1</th>
   <th>2</th>
   <th>3</th>
   <th>4</th>
   <th>5</th>
   <th>6</th>
   <th>7</th>
   <th>8</th>
   <th>9</th>
   <th>10</th>
    </tr>
     <tr>
    <th>阶段</th>
    <td>网站注册</td>
    <td>数据上传</td>
    <td>认证申请</td>
    <td>材料初核</td>
    <td>补充材料</td>
    <td>专家审核</td>
    <td>现场待核</td>
    <td>现场重审</td>
    <td>专家投票</td>
    <td>通过评审</td>
    </tr>
     <tr>
    <th>说明</th>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    <td><input type="text" name="input1" value="" style="width:100%; height:100%;"></td>
    </tr>
    
  </table>

  </form>

 </center><div class="skins">
		<h2>当前进度为:</h2>
			
	</div>

<!-- actual preloader -->
	<div class="loader">
		<div class="progress-bar"><div class="progress-stripes"></div><div class="percentage">0%</div></div>
	</div>

	<span1>Loading...</span1>



  <script src="/assets/js/index.js"></script>
<div style="text-align:center;clear:both">
<script src="/gg_bd_ad_720x90.js" type="text/javascript"></script>

</div>
</div>

<!--content end-->

<!--footer start-->
<?php include 'common/_footer.php' ?>
<!--footer end-->
</div>
</body>
</html>
