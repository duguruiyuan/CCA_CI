<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="" />
<meta name="keywords" content="" />
<title>中国急性心肌梗死救治项目</title>
<link href="/assets/css/base.css" rel="stylesheet" type="text/css">
<link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link  href="/assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/assets/css/base.css" rel="stylesheet" type="text/css">
<link href="/assets/css/style.css" rel="stylesheet" type="text/css" media="all">
<link href="/assets/css/shouye.css" rel="stylesheet" type="text/css">

<!-- <script src="/js/jquery.min.js"></script> -->
<script src="/assets/js/jquery-1.11.3.min.js"></script>
<script src="/assets/js/bootstrap.min.js"></script>
<script src="/assets/js/md5.min.js"></script>
<script type="text/javascript" language="javascript" src="/assets/js/jquery.dropdownPlain.js"></script>
</head>

<body>
<!--header start-->

<?php  include 'common/_header.php'  ?>
<!--header end-->

<!--content start-->
<div style="width:800px; height:1000px; margin:0 auto;">
 <h3 style="text-align:center; margin-top:20px;">讲师新秀</h3>
  <center>
   <table >
   <tr style="text-align:center; height:100px;"><td><div style="margin-top:30px;">
   <p>刘强：广东省深圳市孙逸仙心血管医院</p>
    <div style="float:left;"><img src="../../../../assets/img/docter.jpg" width="100px;" height="120px;"></div>
    <div style="width:500px; float:left; margin-left:10px; text-indent:2em; line-height:20px; text-align:left">所在科室：CCU室
　　刘强，男，主任医师。1986年毕业于第一军医大学医疗系，1993年调入深圳市孙逸仙心血管医院心内科工作，现任孙逸仙心血管医院CCU病房（暨冠心病重症监护病房）主任、学科带头人。主要研究方向心血管介入治疗。　　1986年毕业后一直从事心血管内科临床工作，对心血管疾病常见病、危重症、疑难杂症的临床诊断治疗有丰富的临床经验及独到的见解。曾先后在中国北京阜外医院、德国柏林心脏中心、香港威尔斯亲王医院学......
</div>
  </div></td></tr><hr/>
    <tr style="text-align:center; height:100px;"><td><div style="margin-top:30px;">
   <p>刘强：广东省深圳市孙逸仙心血管医院</p>
    <div style="float:left;"><img src="../../../../assets/img/docter.jpg" width="100px;" height="120px;"></div>
    <div style="width:500px; float:left; margin-left:10px; text-indent:2em; line-height:20px; text-align:left">所在科室：CCU室
　　刘强，男，主任医师。1986年毕业于第一军医大学医疗系，1993年调入深圳市孙逸仙心血管医院心内科工作，现任孙逸仙心血管医院CCU病房（暨冠心病重症监护病房）主任、学科带头人。主要研究方向心血管介入治疗。　　1986年毕业后一直从事心血管内科临床工作，对心血管疾病常见病、危重症、疑难杂症的临床诊断治疗有丰富的临床经验及独到的见解。曾先后在中国北京阜外医院、德国柏林心脏中心、香港威尔斯亲王医院学......
</div>
  </div></td></tr>
   <tr style="text-align:center; height:100px;"><td><div style="margin-top:30px;">
   <p>刘强：广东省深圳市孙逸仙心血管医院</p>
    <div style="float:left;"><img src="../../../../assets/img/docter.jpg" width="100px;" height="120px;"></div>
    <div style="width:500px; float:left; margin-left:10px; text-indent:2em; line-height:20px; text-align:left">所在科室：CCU室
　　刘强，男，主任医师。1986年毕业于第一军医大学医疗系，1993年调入深圳市孙逸仙心血管医院心内科工作，现任孙逸仙心血管医院CCU病房（暨冠心病重症监护病房）主任、学科带头人。主要研究方向心血管介入治疗。　　1986年毕业后一直从事心血管内科临床工作，对心血管疾病常见病、危重症、疑难杂症的临床诊断治疗有丰富的临床经验及独到的见解。曾先后在中国北京阜外医院、德国柏林心脏中心、香港威尔斯亲王医院学......
</div>
  </div></td></tr>
    <tr style="text-align:center; height:100px;"><td><div style="margin-top:30px;">
   <p>刘强：广东省深圳市孙逸仙心血管医院</p>
    <div style="float:left;"><img src="../../../../assets/img/docter.jpg" width="100px;" height="120px;"></div>
    <div style="width:500px; float:left; margin-left:10px; text-indent:2em; line-height:20px; text-align:left">所在科室：CCU室
　　刘强，男，主任医师。1986年毕业于第一军医大学医疗系，1993年调入深圳市孙逸仙心血管医院心内科工作，现任孙逸仙心血管医院CCU病房（暨冠心病重症监护病房）主任、学科带头人。主要研究方向心血管介入治疗。　　1986年毕业后一直从事心血管内科临床工作，对心血管疾病常见病、危重症、疑难杂症的临床诊断治疗有丰富的临床经验及独到的见解。曾先后在中国北京阜外医院、德国柏林心脏中心、香港威尔斯亲王医院学......
</div>
  </div></td></tr>
   <tr style="text-align:center; height:100px;"><td><div style="margin-top:30px;">
   <p>刘强：广东省深圳市孙逸仙心血管医院</p>
    <div style="float:left;"><img src="../../../../assets/img/docter.jpg" width="100px;" height="120px;"></div>
    <div style="width:500px; float:left; margin-left:10px; text-indent:2em; line-height:20px; text-align:left">所在科室：CCU室
　　刘强，男，主任医师。1986年毕业于第一军医大学医疗系，1993年调入深圳市孙逸仙心血管医院心内科工作，现任孙逸仙心血管医院CCU病房（暨冠心病重症监护病房）主任、学科带头人。主要研究方向心血管介入治疗。　　1986年毕业后一直从事心血管内科临床工作，对心血管疾病常见病、危重症、疑难杂症的临床诊断治疗有丰富的临床经验及独到的见解。曾先后在中国北京阜外医院、德国柏林心脏中心、香港威尔斯亲王医院学......
</div>
  </div></td></tr>
   
   </table>
   </center>
</div>
<!--content end-->
<!--footer start-->
<?php include 'common/_footer.php' ?>
<!--footer end-->
</div>
</body>
</html>
