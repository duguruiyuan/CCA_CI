<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="" />
<meta name="keywords" content="" />
<title>滔滔洪水，难挡中国胸痛中心前行之路！</title>
<link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link  href="/assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/assets/css/base.css" rel="stylesheet" type="text/css">
<link href="/assets/css/query.css" rel="stylesheet" type="text/css">
<link href="/assets/css/style.css" rel="stylesheet" type="text/css">
<!-- <script src="/js/jquery.min.js"></script> -->
<script src="/assets/js/jquery-1.11.3.min.js"></script>
<script src="/assets/js/bootstrap.min.js"></script>
<script src="/assets/js/md5.min.js"></script> 
<script src="/assets/js/index.js"></script>

<script type="text/javascript" language="javascript" src="/assets/js/jquery.dropdownPlain.js"></script>
<style>



</style>	

</head>

<body>

<div id="wrapper" class="homebg">
<!--header start-->
<?php  include 'common/_header.php'  ?>
<!--header end-->
  
  <div id="container">
    <div style="width:800px; margin:0 auto;">
      <p>
      <h2 style="text-align:center;">滔滔洪水，难挡中国胸痛中心前行之路！</h2>
      <br>
     
      </p>
      <h6style="margin-top:30px; margin-bottom:30px;">时间：2016-07-07    来源：中国胸痛中心网</h6>
      <center>
       
      </center>
      <p  style="text-indent:2em;line-height:30px; font-size:16px;">第八批中国胸痛中心认证工作正在全国进行中，根据计划，7月6日对武汉市中心医院进行胸痛中心进行现场核查。李浪院长、杨丽霞教授在洪水中前行，而此时的武汉由于持续强降雨导致多地洪涝灾害，路段积水严重，交通受阻。尽管如此，广西医科大学第一附属医院李浪院长、成都军区昆明总医院杨丽霞教授、上海交通大学医学院附属苏州九龙医院刘峰院长三位中国胸痛中心认证工作委员会委员，及中国胸痛中心区域认证办公室林吉怡组 成认证专家小组，不惧危险，按时抵达武汉。刘峰院长前往武汉市中心医院7月5日晚上突然经历了一夜狂风暴雨，武汉城区交通全面瘫痪，启动了排渍红色预警！但我们三位认证专家依然不畏艰难，乘坐120 救护车前往单位核查。途中，由于大雨如注，路旁的积水已有公交车的三分之一高，经过一路颠簸，在离院还有约300米的距离时，救护车熄火了。为了让认证工作 照常进行，三位专家及认证工作人员不顾暴雨，换上拖鞋，挽起裤脚，打起雨伞在滔滔地洪水中步行到医院。最可贵的是，尽管路途狼狈，满身疲惫，但他们还是 怀着认真严谨、共同学习的态度，从急诊科、导管室到CCU病区等每个环节、细节仔细进行核查，并对此作出总结与反馈。三位专家现场核查中，在急诊科抢救室进行核查暴风雨中挽起裤脚核查的专家让我们感动！认证专家的执着精神与严谨的态度值得我们去尊敬！胸痛中心的建设在风雨中前行，在 认证的过程中谱写出新的篇章！</p>
  
      <hr>
    </div>
  </div>
  
  <!--content end--> 
  
<!--footer start-->
<?php include 'common/_footer.php' ?>
<!--footer end-->
</div>

</body>
</html>
