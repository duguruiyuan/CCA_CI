<!--footer start-->
<div id="footer">

<div class="link_">
        <ul>
        <li><a href="/home">首页</a></li>
        <li><a href="">认证</a></li>
        <li><a href="underConstruction.html">质控</a></li>
        <li><a href="underConstruction.html">培训</a></li>
        <li><a href="underConstruction.html">发展动态</a></li>
        <li><a href="underConstruction.html">示范中心</a></li>
        <li><a href="underConstruction.html">基层胸痛</a></li>
        <li><a href="underConstruction.html">学习天地</a></li>
        <li><a href="underConstruction.html">星火计划</a></li>
        
        </ul>
        </div>
    <div class="link">
 
        <ul>
            <li>相关链接</li>
            <li><a href="http://csc.cma.org.cn/" target="_parent">中华医学会心血管病分会</a></li>
            <li><a href="http://www.chhouse.org/" target="_parent">中国心血管健康联盟</a></li>
        </ul>
    </div>

    <div class="copyright"><p><!---<span>© 悟提供技术支持：QQ724070605</span>-->苏ICP备10000000号-7</p></div>
    
</div>

<!--footer end-->