<?php
class Rz_upload_model extends MY_Model
{
    protected $TBL_NAME = 'rz_upload';
}
?>