<?php
class Recycle_model extends MY_Model
{
    protected $TBL_NAME = 'recycle';
}
?>