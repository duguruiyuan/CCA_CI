<?php
class Ly_model extends MY_Model
{
    protected $TBL_NAME = 'ly';
}
?>